package com.training;

public class AgeIsNotWithInTheRangeException {

	
	     public String toString()
	     {
	          return ("Age is not between 15 and 21. please ReEnter the Age");
	     }
	}
